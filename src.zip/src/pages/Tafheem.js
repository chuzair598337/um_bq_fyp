import React from 'react'

function Tafheem() {
  return (
    <div>Tafheem</div>
  )
}

export default Tafheem