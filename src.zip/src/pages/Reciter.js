import React from 'react'

function Reciter() {
  return (
    <div>Reciter</div>
  )
}

export default Reciter